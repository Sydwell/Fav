import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-new',
  templateUrl: './profile-new.component.html',
  styleUrls: ['./profile-new.component.css']
})
export class ProfileNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
